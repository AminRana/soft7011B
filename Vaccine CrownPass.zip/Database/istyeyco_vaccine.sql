-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 03, 2022 at 06:44 AM
-- Server version: 10.3.34-MariaDB-log-cll-lve
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `istyeyco_vaccine`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `vcid` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `saved_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `sid`, `uid`, `vcid`, `date`, `note`, `status`, `saved_time`) VALUES
(6, 'f3f3c91baf5660810cfce3652e8dc01e', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '11118450c9b2bf280c8ba55487b28225', '2022-05-20', 'urgent needed test', 2, '2022-05-01 18:03:47'),
(4, '00670ed62660575f64ca43681872b71f', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '4ca38b961f81040c397b29091f8daef6', '2022-05-27', 'urgent needed', 2, '2022-05-01 17:28:01'),
(7, 'e74e6baad4419126f864edd92f0ca944', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '4ca38b961f81040c397b29091f8daef6', '2022-05-12', 'urgent needed test 2', 3, '2022-05-01 18:25:14'),
(8, '8e828be4c1d11c76cd32b219a0fba479', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '11118450c9b2bf280c8ba55487b28225', '2022-05-27', 'urgent needed test 3', 3, '2022-05-01 18:42:07'),
(9, 'eb92b33eed86c5eb8f0aaf314d456cc5', '00a8c082ae73c0a23b0deea4e0f34fb1', '11118450c9b2bf280c8ba55487b28225', '2022-05-28', 'health worker urgent vaccine', 2, '2022-05-01 23:00:25'),
(10, '84493cf09fd35ea9f48ebf9a5633e89f', '00a8c082ae73c0a23b0deea4e0f34fb1', '4ca38b961f81040c397b29091f8daef6', '2022-05-31', 'urgent needed test 3', 2, '2022-05-01 23:16:05'),
(11, 'ee209556d1cfbadc165f0e4b6d667adb', '00a8c082ae73c0a23b0deea4e0f34fb1', '4ca38b961f81040c397b29091f8daef6', '2022-05-17', 'urgent needed test 2', 1, '2022-05-01 23:16:38'),
(12, '0766b4a57d9291983ca2cea3f83101f3', 'de918025e8f11661b8f428ba81d0e10a', '11118450c9b2bf280c8ba55487b28225', '2022-05-13', 'gfffg', 0, '2022-05-01 23:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `last_login`
--

CREATE TABLE `last_login` (
  `id` int(11) NOT NULL,
  `last_username` varchar(100) NOT NULL,
  `last_date_time` varchar(100) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `last_login`
--

INSERT INTO `last_login` (`id`, `last_username`, `last_date_time`) VALUES
(1, 'kmistiyakhossain@gmail.com', '2022-05-01 15:59:57'),
(2, 'admin@vaccine.isty.me', '2022-05-01 16:09:12'),
(3, 'admin@vaccine.isty.me', '2022-05-01 16:11:23'),
(4, 'admin2@vaccine.isty.me', '2022-05-01 16:14:34'),
(5, 'admin2@vaccine.isty.me', '2022-05-01 16:52:14'),
(6, 'admin2@vaccine.isty.me', '2022-05-01 16:52:19'),
(7, 'admin2@vaccine.isty.me', '2022-05-01 16:53:50'),
(8, 'admin2@vaccine.isty.me', '2022-05-01 16:53:52'),
(9, 'admin2@vaccine.isty.me', '2022-05-01 16:56:23'),
(10, 'kmistiyakhossain@gmail.com', '2022-05-01 18:46:26'),
(11, 'kmistiyakhossain@gmail.com', '2022-05-01 18:46:35'),
(12, 'kmistiyakhossain@gmail.com', '2022-05-01 18:46:41'),
(13, 'kmistiyakhossain@gmail.com', '2022-05-01 18:46:44'),
(14, 'kmistiyakhossain@gmail.com', '2022-05-01 18:49:45'),
(15, 'kmistiyakhossain@gmail.com', '2022-05-01 18:50:08'),
(16, 'kmistiyakhossain@gmail.com', '2022-05-01 18:50:25'),
(17, 'kmistiyakhossain@gmail.com', '2022-05-01 18:50:46'),
(18, 'kmistiyakhossain@gmail.com', '2022-05-01 18:51:00'),
(19, 'kmistiyakhossain@gmail.com', '2022-05-01 18:51:26'),
(20, 'kmistiyakhossain@gmail.com', '2022-05-01 18:51:28'),
(21, 'kmistiyakhossain@gmail.com', '2022-05-01 18:51:59'),
(22, 'velay75827@pantabi.com', '2022-05-01 18:54:49'),
(23, 'admin@vaccine.isty.me', '2022-05-01 18:58:40'),
(24, 'velay75827@pantabi.com', '2022-05-01 19:01:08'),
(25, 'velay75827@pantabi.com', '2022-05-01 19:02:27'),
(26, 'velay75827@pantabi.com', '2022-05-01 19:28:03'),
(27, 'fikoka9277@richdn.com', '2022-05-01 19:39:22'),
(28, 'admin@vaccine.isty.me', '2022-05-02 16:01:19');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `jobTitle` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `staffNumber` varchar(255) NOT NULL,
  `vaccineAffectedStatus` varchar(255) NOT NULL,
  `vaccineStatus` varchar(255) NOT NULL,
  `savedTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`id`, `name`, `email`, `home`, `jobTitle`, `password`, `phoneNumber`, `qrcode`, `staffNumber`, `vaccineAffectedStatus`, `vaccineStatus`, `savedTime`) VALUES
(2, 'Istiyak Hossain', 'kmistiyakhossain@gmail.com', '17/4, Tollabag', 'Software Engineer', '25f9e794323b453885f5181f1b624d0b', '+8801680901286', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '123456', '0', '1', '2022-05-01 22:51:21'),
(3, 'Test User', 'user@gmail.com', '21, Sukrabad, Dhaka 1207', 'Public User', '25f9e794323b453885f5181f1b624d0b', '01680901287', 'cba1f2d695a5ca39ee6f343297a761a4', '123456789', '0', '0', '2022-04-23 18:17:57'),
(4, 'Test User 2', 'user2@gmail.com', 'Dhaka bangladesh', 'Service Holder', '25f9e794323b453885f5181f1b624d0b', '01234567890', 'fa7c3fcb670a58aa3e90a391ea533c99', '123456789', '2', '1', '2022-04-23 18:25:50'),
(5, 'Maruf Alam', 'marufalam120@gmail.com', 'Dhaka', 'Student', 'e10adc3949ba59abbe56e057f20f883e', '1687422428', '6881c46be9e2dfc54a20855ab3b8d3bc', '', '2', '1', '2022-04-24 14:54:36'),
(6, 'KAL', 'KAL@gmail.com', 'London', 'Student', '903292a5a4586568852bb8804df9640e', '07574861067', '933485182d025295283388cbc8d68caa', '', '0', '0', '2022-04-25 17:11:26'),
(7, 'Test User', 'test@gmail.com', 'abcdefg', 'aaa', '25f9e794323b453885f5181f1b624d0b', '0123456789', '1aedb8d9dc4751e229a335e371db8058', '123456', '0', '0', '2022-04-30 21:22:45'),
(8, 'Oliver Arthur', 'admin@vaccine.isty.me', 'Blackshaw Rd, London SW17 0QT, United Kingdom', 'Administration', 'e10adc3949ba59abbe56e057f20f883e', '+442086721255', '8867a377d6218d169fba958606a1cae1', '', '0', '0', '2022-05-01 20:06:44'),
(9, 'Bedford Hospital South Wing', 'admin2@vaccine.isty.me', 'South Wing, Kempston Rd, Bedford MK42 9DJ, United Kingdom', 'Vaccine Center Authority', '25d55ad283aa400af464c76d713c07ad', '+441234355122', '5f57ce906df2b912d32baaa81fedd60c', '', '0', '0', '2022-05-01 20:51:52'),
(10, 'Alexender Mishal', 'velay75827@pantabi.com', 'London UK', 'Health Worker', 'e10adc3949ba59abbe56e057f20f883e', '+44123456785', '00a8c082ae73c0a23b0deea4e0f34fb1', '987456321', '0', '2', '2022-05-01 23:02:09'),
(11, 'Test User 6', 'xocivek172@pantabi.com', 'test test test', 'Test Title', 'e10adc3949ba59abbe56e057f20f883e', '0123456789', '1b6fdae1ff638e0a840841f2b4b14365', '123456', '0', '0', '2022-05-01 23:29:08'),
(12, 'Test User 2', 'fikoka9277@richdn.com', '12/23, Road B, Block C', 'Public User', 'e10adc3949ba59abbe56e057f20f883e', '+8801819151593', 'de918025e8f11661b8f428ba81d0e10a', '123456', '0', '0', '2022-05-01 23:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `rid` int(11) NOT NULL,
  `id` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `user_group` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `kicked` int(1) NOT NULL DEFAULT 0,
  `addedTime` varchar(255) NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`rid`, `id`, `username`, `password`, `email`, `phone`, `first_name`, `last_name`, `user_group`, `status`, `kicked`, `addedTime`, `date`) VALUES
(1, '4a8b5c7269aeb230a17f2c937aa10c6c', 'admin@dmstc2000.com', '25f9e794323b453885f5181f1b624d0b', 'kmistiyakhossain@gmail.com', '01680901286', '', '', 1, 1, 0, '2021-02-07 05:16:28', '0000-00-00'),
(5, '8867a377d6218d169fba958606a1cae1', '', 'e10adc3949ba59abbe56e057f20f883e', 'admin@vaccine.isty.me', '', '', '', 1, 1, 0, '2021-02-07 05:16:28', '0000-00-00'),
(6, '5f57ce906df2b912d32baaa81fedd60c', '', '25d55ad283aa400af464c76d713c07ad', 'admin2@vaccine.isty.me', '', '', '', 1, 1, 0, '2021-02-07 05:16:28', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `user_otp`
--

CREATE TABLE `user_otp` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `code` varchar(10) NOT NULL,
  `token` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `savedTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_otp`
--

INSERT INTO `user_otp` (`id`, `email`, `code`, `token`, `uid`, `savedTime`) VALUES
(5, 'kmistiyakhossain@gmail.com', '136235', '4eb113d731a90cc92c027c13a753379a', '6aa3df7c59a3b700be0cf7fcb78b2eaa', '2022-05-01 22:48:04'),
(6, 'velay75827@pantabi.com', '310925', 'e224c5f73da9c653bef873549bcb50ce', '00a8c082ae73c0a23b0deea4e0f34fb1', '2022-05-01 23:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `vaccine_centre`
--

CREATE TABLE `vaccine_centre` (
  `id` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL DEFAULT 'N/A',
  `map_link` text NOT NULL DEFAULT 'N/A',
  `status` int(11) NOT NULL DEFAULT 0,
  `savedTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vaccine_centre`
--

INSERT INTO `vaccine_centre` (`id`, `sid`, `name`, `code`, `phone`, `address`, `map_link`, `status`, `savedTime`) VALUES
(2, '4ca38b961f81040c397b29091f8daef6', 'Central London', 'LH-1001A', '+44123456789', '11 Collier St, London N1 9JU, United Kingdom', 'https://goo.gl/maps/1JurcVhyoVa5qUDJA', 0, '2022-05-01 19:43:16'),
(3, '11118450c9b2bf280c8ba55487b28225', 'Emirates Stadium', 'ES-1002A', '+44123456788', 'Hornsey Rd, London N7 7AJ, United Kingdom', 'https://goo.gl/maps/KF9rvQy7XoYkqs1T8', 0, '2022-04-30 19:20:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `last_login`
--
ALTER TABLE `last_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `user_otp`
--
ALTER TABLE `user_otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vaccine_centre`
--
ALTER TABLE `vaccine_centre`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `last_login`
--
ALTER TABLE `last_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_otp`
--
ALTER TABLE `user_otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vaccine_centre`
--
ALTER TABLE `vaccine_centre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
